#!/usr/bin/env python3


from gendiff import print_hi


def main():
    print_hi()

if __name__ == '__main__':
    main()
