#!/usr/bin/env python3


from gendiff import start, seach_different


def main():
    args = start()
    print(args)
    seach_different(args.first_file, args.second_file, formater=args.format)


if __name__ == '__main__':
    main()
