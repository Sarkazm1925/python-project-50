### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sarkazm1925/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Sarkazm1925/python-project-50/actions)
### CodeClimate test
[![Maintainability](https://api.codeclimate.com/v1/badges/5cb2102d602d48fd8793/maintainability)](https://codeclimate.com/github/Sarkazm1925/python-project-50/maintainability)
